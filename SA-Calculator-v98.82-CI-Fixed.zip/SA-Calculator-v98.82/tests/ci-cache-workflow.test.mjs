import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const workflow = fs.readFileSync('.github/workflows/main.yml', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

test('CI caches npm downloads without requiring a missing lockfile', () => {
  assert.equal(fs.existsSync('package-lock.json'), false,
    'this release intentionally uses npm install without a committed lockfile');
  assert.ok(workflow.includes('uses: actions/cache@v6'));
  assert.ok(workflow.includes('path: ~/.npm'));
  assert.ok(workflow.includes("hashFiles('**/package.json')"));
  assert.ok(workflow.includes('npm-${{ runner.os }}-node24-'));
  assert.ok(workflow.includes("node-version: '24'"));
  assert.ok(workflow.includes('package-manager-cache: false'));
});

test('npm cache is restored before dependency installation', () => {
  assert.ok(workflow.indexOf('name: Cache npm downloads') < workflow.indexOf('name: Install npm dependencies'));
  assert.ok(pkg.dependencies['@capacitor/core']);
  assert.ok(pkg.dependencies['@capacitor/android']);
});

test('v98.82 release identity and exact service-worker cache namespace are synchronized', () => {
  const expected = '1.98.96-v98.82';
  assert.equal(pkg.version, expected);
  assert.equal(pkg.androidVersionCode, 1099102);
  assert.ok(fs.readFileSync('index.html', 'utf8').includes(expected));
  assert.ok(fs.readFileSync('assets/js/app.js', 'utf8').includes(`const APP_VERSION = '${expected}'`));
  assert.equal(JSON.parse(fs.readFileSync('manifest.webmanifest', 'utf8')).version, expected);
  const sw = fs.readFileSync('service-worker.js', 'utf8');
  const cache = sw.match(/^const CACHE='([^']+)'/m)?.[1];
  assert.equal(cache, 'sa-calculator-v98-82-gst-keypad-audit-v9882');
  assert.ok(workflow.includes("const expectedCache='sa-calculator-v98-82-gst-keypad-audit-v9882'"));
  assert.ok(!workflow.includes("if(!sw.includes('v9881'))"));
});

test('Android workflow test-entry validation rejects merged test-path tokens', () => {
  const command = pkg.scripts['test:release'];
  assert.equal(workflow.includes("tests/action-time-lifecycle-hardening-v9881.test.mjs tests/action-time-ui-geometry-v9881.test.mjs"), false);
  const commandFiles = [...command.matchAll(/(?:^|\s)(tests\/[^\s]+)/g)].map(m => m[1]);
  assert.ok(commandFiles.length >= 10);
  for (const file of commandFiles) assert.equal(fs.existsSync(file), true, `release test entry references missing file: ${file}`);
  const workflowListStart = workflow.indexOf('for(const f of [');
  const workflowListEnd = workflow.indexOf(']) {', workflowListStart);
  const workflowList = workflow.slice(workflowListStart, workflowListEnd);
  const workflowTestFiles = [...workflowList.matchAll(/'(tests\/[^']+\.test\.(?:mjs|js))'/g)].map(m => m[1]);
  assert.ok(workflowTestFiles.length >= 7);
  for (const file of workflowTestFiles) {
    assert.equal(fs.existsSync(file), true, `workflow verification list references missing file: ${file}`);
    assert.ok(commandFiles.includes(file), `workflow verification file is not in release test entry: ${file}`);
  }
});

test('Android workflow validates real release test paths and Android version code', () => {
  assert.ok(workflow.includes('if(p.androidVersionCode!==1099102)'));
  assert.ok(workflow.includes('tests/tool-restoration-regression-v9870.test.mjs'));
  assert.ok(workflow.includes("tests/tool-reference-video-regression-v9873.test.mjs"));
  assert.ok(workflow.includes('tests/tool-reference-finance-regression-v9881.test.mjs'));
  assert.ok(workflow.includes('tests/tool-reference-video-regression-v9873.test.mjs'));
  assert.ok(workflow.includes('tests/tool-reference-finance-regression-v9881.test.mjs'));
  assert.ok(pkg.scripts['test:release'].includes('tests/tool-reference-video-regression-v9873.test.mjs'));
  assert.ok(workflow.includes('tests/tool-reference-finance-regression-v9881.test.mjs'));
  assert.ok(pkg.scripts['test:release'].includes('tests/tool-reference-finance-regression-v9881.test.mjs'));
  assert.ok(!workflow.includes('tests/tool-removal-regression-v9869.test.mjs'));
  for (const file of ['tests/tool-restoration-regression-v9870.test.mjs', 'assets/js/app.js', 'assets/css/app.css', 'assets/css/tool-reference-ui.css']) {
    assert.equal(fs.existsSync(file), true, `required workflow file missing: ${file}`);
  }
});

test('release JavaScript source has no literal escaped v98.81 hardening suffix', () => {
  const app = fs.readFileSync('assets/js/app.js', 'utf8');
  assert.ok(!app.includes('\\n\\n/* v98.81 TOOL BEHAVIOR HARDENING'),
    'app.js contains a literal escaped-newline hardening suffix; JavaScript would fail syntax validation');
  assert.ok(!fs.readFileSync('assets/css/tool-reference-ui.css', 'utf8').includes('\\n\\n/* v98.81:'),
    'tool-reference-ui.css contains a literal escaped-newline suffix');
});


test('Android workflow uses current Node 24-compatible official action majors', () => {
  for (const [action, major] of [
    ['actions/checkout', 'v7'],
    ['actions/setup-node', 'v7'],
    ['actions/cache', 'v6'],
    ['actions/setup-java', 'v6'],
    ['gradle/actions/setup-gradle', 'v6'],
    ['android-actions/setup-android', 'v4'],
    ['actions/upload-artifact', 'v7'],
  ]) assert.ok(workflow.includes(`uses: ${action}@${major}`), `${action}@${major} must be configured`);
  assert.equal(fs.readFileSync('Android-Workflow-v98.81.yml', 'utf8'), workflow,
    'standalone workflow and repository workflow must remain byte-identical');
});
