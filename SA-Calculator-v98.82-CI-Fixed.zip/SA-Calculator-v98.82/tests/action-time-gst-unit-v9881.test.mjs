import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync('index.html','utf8');
const js=fs.readFileSync('assets/js/app.js','utf8');
const css=fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const workflow=fs.readFileSync('Android-Workflow-v98.81.yml','utf8');

test('v98.81 GST result matches the reference row model for same and different state',()=>{
  assert.match(html,/id="tax-sgst-row"/);
  assert.match(html,/id="tax-cgst-row"/);
  assert.match(html,/id="tax-igst-row"/);
  assert.match(js,/tax-sgst-label/);
  assert.match(js,/tax-cgst-label/);
  assert.match(js,/tax-igst-label/);
  assert.match(js,/tax-sgst-row.*toggleAttribute\('hidden', !same\)/s);
  assert.match(js,/tax-cgst-row.*toggleAttribute\('hidden', !same\)/s);
  assert.match(js,/tax-igst-row.*toggleAttribute\('hidden', same\)/s);
  assert.match(css,/\.gst-video-result-row\[hidden\]\s*\{\s*display:none !important/);
});

test('v98.81 GST preserves a committed result when mode, rate or place is changed',()=>{
  const block=js.slice(js.indexOf("document.querySelectorAll('[data-gst-mode]')"),js.indexOf("document.getElementById('unit-price-compare')"));
  assert.match(block,/wasCalculated = screen\?\.dataset\.toolCalculated === 'true'/g);
  assert.ok((block.match(/wasCalculated/g)||[]).length >= 3);
  assert.match(block,/if \(!wasCalculated\) invalidateToolCalculation\('salestax'\)/);
  assert.match(block,/if \(wasCalculated\) screen\.dataset\.toolCalculated = 'true'/);
});

test('v98.81 GST input enforces the reference nine-digit ceiling and grouped display',()=>{
  assert.match(js,/isGstAmount.*tax-orig/);
  assert.match(js,/appendLimitedNumericKey\(val \|\| '0', key, isGstAmount \? 9/);
  assert.match(js,/Amount cannot exceed 99,99,99,999/);
  assert.match(js,/orig <= 999999999/);
  assert.match(js,/formatEditableToolNumber\(val\)/);
});

test('v98.81 Unit Converter exposes exactly one visible selector per From/To card',()=>{
  assert.doesNotMatch(html,/id="unit-from-display"/);
  assert.doesNotMatch(html,/id="unit-to-display"/);
  assert.match(css,/unit-select-wrap > \.unit-code-display[\s\S]*display:none !important/);
  assert.match(css,/\.unit-select-wrap > \.sumaire-select-trigger/);
});

test('v98.81 release identity and CI entry are synchronized',()=>{
  assert.equal(pkg.version,'1.98.96-v98.82');
  assert.equal(pkg.androidVersionCode,1099102);
  assert.match(workflow,/SA_EXPECTED_VERSION: '1\.98\.96-v98\.82'/);
  assert.match(workflow,/androidVersionCode!==1099102/);
  assert.match(workflow,/action-time-gst-unit-v9881\.test\.mjs/);
});
