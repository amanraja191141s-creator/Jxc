import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync('index.html','utf8');
const js = fs.readFileSync('assets/js/app.js','utf8');
const css = fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
const workflow = fs.readFileSync('Android-Workflow-v98.81.yml','utf8');

 test('v98.81 identity and cache namespace are fresh', () => {
  const pkg = JSON.parse(fs.readFileSync('package.json','utf8'));
  assert.equal(pkg.version, '1.98.96-v98.82');
  assert.equal(pkg.androidVersionCode, 1099102);
  assert.match(html, /1\.98\.96-v98\.82/);
  assert.match(js, /const APP_VERSION = '1\.98\.96-v98\.82'/);
  assert.match(fs.readFileSync('service-worker.js','utf8'), /sa-calculator-v98-82-gst-keypad-audit-v9882/);
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.96-v98\.82'/);
  assert.match(workflow, /androidVersionCode!==1099102/);
 });

test('currency reference surface removes non-video controls and starts USD to INR blank', () => {
  assert.match(html, /id="currency-from-field"/);
  assert.match(html, /id="currency-to-field"/);
  assert.match(html, /id="cur-from-short-name">Dollar/);
  assert.match(html, /id="cur-to-short-name">Rupee/);
  assert.doesNotMatch(html, /class="currency-refresh-toolbar"/);
  assert.match(js, /return \{ from: 'USD', to: 'INR' \};/);
  assert.match(js, /amountEl\.querySelector\('\.input-text'\)\.textContent='';/);
  assert.match(css, /#screen-currencies \.currency-reference-field/);
  assert.match(css, /#screen-currencies #cur-rate-status,#screen-currencies #cur-refresh-time/);
});

test('GST and discount use equals action instead of visible Calculate controls', () => {
  assert.match(css, /#screen-salestax #tax-calculate,#screen-salestax \.reference-info-note \{ display:none/);
  assert.match(css, /#screen-discount \.discount-tax-compat,#screen-discount \.reference-primary-action \{ display:none/);
  for (const id of ['disc-original-result','disc-rate-result','disc-amount','disc-saved','disc-final']) assert.ok(html.includes(`id="${id}"`), id);
});

test('unit converter matches reference categories and defaults', () => {
  for (const cat of ['mass','length','area','time','volume','temperature','speed','data','power','current','voltage']) assert.match(html, new RegExp(`data-unit-category="${cat}"`));
  assert.match(js, /current: \{ base: 'A'/);
  assert.match(js, /voltage: \{ base: 'V'/);
  assert.match(js, /cat === 'time'\) \{ f\.value = 'Second \(s\)'; t\.value = 'Year \(365 d\)'/);
  assert.match(js, /cat === 'volume'\) \{ f\.value = 'Liter \(L\)'; t\.value = 'US liquid gallon \(gal\)'/);
  assert.match(js, /cat === 'current'\) \{ f\.value = 'Ampere \(A\)'; t\.value = 'Kiloampere \(kA\)'/);
  assert.match(js, /cat === 'voltage'\) \{ f\.value = 'Volt \(V\)'; t\.value = 'Millivolt \(mV\)'/);
  assert.match(css, /#screen-units \.unit-category-grid/);
  assert.match(css, /#screen-units #unit-category-back,#screen-units \.unit-category-state \{ display:none/);
});

test('age is the only supplied reference tool that keeps its in-screen Calculate action without auto keypad', () => {
  assert.match(html, /id="age-calculate"/);
  assert.match(js, /const AUTO_TOOL_KEYPAD_SCREENS = new Set\(\['currencies'.*'hex'\]\)/s);
  assert.doesNotMatch(js, /AUTO_TOOL_KEYPAD_SCREENS[^\n]*agecalc/);
});

test('shared keypad and tool screens are touch-safe at action time', () => {
  assert.match(css, /grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/);
  assert.match(css, /grid-template-rows:repeat\(4,minmax\(0,1fr\)\)/);
  assert.match(css, /touch-action:manipulation/);
  assert.match(js, /if \(STATE\.currentScreen === 'units' \|\| STATE\.currentScreen === 'currencies'\)/);
  assert.match(js, /Maximum 3 digits allowed/);
});
